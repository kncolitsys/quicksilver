Copyright 2009 Brian Carr

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
   
   Co-developed with Micky Dionisio
   
INSTRUCTIONS
1. Extract framework and samples zip file contents to web root.
2. Ensure either ColdSpring or Lightwire is also correctly installed.
3. Navigate to samples directory {web-root}/samples.

Release Notes;

0.5.88 (10/6/2009)
- Updated to work with CF 9 full release! (including samples)
- Now allow for custom-defined formats (via extension) and associated content types with new config option
	this.quicksilver.formats - example usage; this.quicksilver.formats = [{format='.bleh', contentType='text/html'}, {format='.blah', contentType='text/css'}];
- Added new built-in AOP aspect 'authFilter' which parses HTTP Basic authentication credentials when present (for rest web services), when that aspect
	is applied before a method invocation, two arguments are added to the runtime argument collection named: auth_username and auth_password which
	can be referenced / used in any subsequent method invocation.
- Fixed but where incorrect behavior was occurring when both webroot and application root were the same directory.
- Fixed a bug that was causing an error when returning JSON with no @returnTypeName annotation.
- Fixed an Application.cfc onMissingMethod issue that was causing incorrect behavior.

0.4.79 (09/10/2009)
- Created a new application configuration called this.quicksilver.viewRoot - global applicaiton of the view 
	root that can be overriden on the component level at any time.
- Improved performance by defaulting reload to 'false' - it now does not check to see if the framework needs 
	to be reloaded on every request unless the reload key exists (this.quicksilver.reload = true).
- Added default behavior so when a map is not found, it will default to 'looking' for an associated .cfm 
	view within the globalviewroot if no globalviewroot has been specified, then it will look for a view 
	in the web root.  There is no more need for component controller methods that do nothing more than 
	render a view.
- Fixed an issue where the main method interceptor was only returning the AOP arguments 
	structure and not the actual method return type.
- Fixed an issue with @returnTypeName annotated method where the value for that annotation was 
	no being used properly to store the return results of its assocaited method in the framework
	argument collection.
- Streamlined naming convention of AOP decorated methods on a target object.
- Fixed an issue affecting AOP methods when in the case those methods would return structure data types, those
	structures were not being appended to the framework argument collection.
- Added cfide, cfdocs and web-inf to the list of default ignored packages.
- Updated sample apps.
- Removed some unused / unecessary files.

0.3.70 (09/01/2009)
- Fixed critical issue with the MappingService that was not correctly matching urls.

0.3.68 (08/31/2009)
- Added improved url-pattern matching features that allow developers to configure url patterns with variables
 	that precede the target template. E.g. /{subject}/{article}/{cfm} == /sports/injuries_on_the_rise/index.cfm
- Fixed a bug with pre-aspect processing that was not properly terminating the chain of execution when encountering
	 a 'halted' condition.
- Fixed an issue that was not properly defaulting returnTypeName and halted variables in the decorated methods attached
	to an object via the RuntimeObjectDecorator.
- Updated samples with the tag-based hello world demo.