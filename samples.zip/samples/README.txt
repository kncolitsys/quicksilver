Quicksilver Samples;

To install, unzip the contents into your CF web root.  Samples should be accessible
within the /samples/ directory.